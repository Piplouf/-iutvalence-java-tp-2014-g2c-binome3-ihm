package tp.java.puissance4.binome4;

public class Position {
	
	private int x,y;
	
	public Position(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	public int retournerX(){
		return this.x;
	}
	
	public int retournerY(){
		return this.y;
	}

}
