package tp.java.puissance4.binome4;

import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Fenetre extends JFrame {

	private static final long serialVersionUID = 1L;

	private Controleur controleur;

	private JButton[][] grille;
	
	private JLabel zoneDeTexte;
	
	private JLabel image;

	public Fenetre(Controleur controleur) {
		
		this.grille = new JButton[6][7];
		this.setTitle("Puissance 4");
		this.setSize(390, 450);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.controleur = controleur;

		JPanel partie = new JPanel();
		JPanel texte = new JPanel();

		JPanel vertical = new JPanel();
		JPanel emplacementBoutons = new JPanel();
		JPanel grille = new JPanel();

		JPanel zoneTexte = new JPanel();
		JPanel zoneImage = new JPanel();

		this.zoneDeTexte = new JLabel("Joueur 1");
		this.image = new JLabel();
		this.image.setIcon(new ImageIcon("src/img/pion_rouge.gif"));

		zoneDeTexte.setPreferredSize(new Dimension(200, 50));
		image.setPreferredSize(new Dimension(50, 50));

		texte.setLayout(new BoxLayout(texte, BoxLayout.LINE_AXIS));
		zoneTexte.add(zoneDeTexte);
		zoneImage.add(image);
		texte.add(zoneTexte);
		texte.add(zoneImage);
		grille.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		grille.setLayout(new GridLayout(6, 7));
		for (int i = 0; i < Plateau.NOMBRE_LIGNES; i++) {
			for (int j = 0; j < Plateau.NOMBRE_COLONNES; j++) {
				grille.add(new JPanel()
						.add(this.grille[i][j] = new BoutonGrille(new Position(
								Plateau.NOMBRE_LIGNES - j, Plateau.NOMBRE_COLONNES - i))));
			}
		}

		emplacementBoutons.setLayout(new GridLayout(1, 7));
		vertical.setLayout(new BoxLayout(vertical, BoxLayout.Y_AXIS));

		for (int z = 1; z < Plateau.NOMBRE_COLONNES + 1; z++) {
			emplacementBoutons.add(new JPanel().add(new Bouton("↓", 50, 30, z,
					controleur,this)));
		}

		vertical.add(texte);
		vertical.add(emplacementBoutons);
		vertical.add(new JLabel("\n"));
		vertical.add(grille);

		partie.add(vertical);
		this.setContentPane(partie);
		this.setVisible(true);

	}
	
	public void modifierCaseGrille(Position pos, Color couleur){
		int y = pos.retournerX();
		int x = Plateau.NOMBRE_LIGNES - 1 - pos.retournerY();
		this.grille[x][y].setBackground(couleur);
	}
	
	public void modifierTexte(String texte){
		this.zoneDeTexte.setText(texte);
	}

	public void chargerCouleur() {

	}
}